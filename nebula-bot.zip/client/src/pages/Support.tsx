import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { Github, Instagram, MessageCircle } from "lucide-react";

export default function Support() {
  const containerRef = useRef(null);

  useEffect(() => {
    gsap.from(containerRef.current, {
      scale: 0.95,
      opacity: 0,
      duration: 1,
      ease: "power3.out",
    });
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center px-6 pt-20">
      <div ref={containerRef} className="max-w-3xl w-full text-center">
        <h2 className="text-display text-4xl md:text-6xl font-bold mb-8">
          GET SUPPORT
        </h2>
        <p className="text-gray-400 text-lg mb-12 max-w-xl mx-auto">
          Need help with Nebula? Join our support server or reach out directly through our social channels.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <a
            href="https://dc.gg/nebula-support"
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center justify-center p-8 glass-panel rounded-2xl hover:bg-white/10 transition-all hover:scale-105 group"
          >
            <MessageCircle className="w-12 h-12 mb-4 text-white group-hover:text-[#5865F2] transition-colors" />
            <span className="text-xl font-bold">Support Server</span>
            <span className="text-sm text-gray-500 mt-2">Join Community</span>
          </a>

          <a
            href="https://instagram.com/arpangameryt"
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center justify-center p-8 glass-panel rounded-2xl hover:bg-white/10 transition-all hover:scale-105 group"
          >
            <Instagram className="w-12 h-12 mb-4 text-white group-hover:text-[#E1306C] transition-colors" />
            <span className="text-xl font-bold">Instagram</span>
            <span className="text-sm text-gray-500 mt-2">@arpangameryt</span>
          </a>

          <a
            href="https://github.com/arpangameryt"
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center justify-center p-8 glass-panel rounded-2xl hover:bg-white/10 transition-all hover:scale-105 group"
          >
            <Github className="w-12 h-12 mb-4 text-white group-hover:text-gray-300 transition-colors" />
            <span className="text-xl font-bold">GitHub</span>
            <span className="text-sm text-gray-500 mt-2">@arpangameryt</span>
          </a>
        </div>
      </div>
    </div>
  );
}
