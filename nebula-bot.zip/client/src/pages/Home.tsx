import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowRight, Shield, Gavel, Gift, Wrench, Ticket, Crown } from "lucide-react";
import logo from "@assets/20251117_101330_1764404311257.png";

gsap.registerPlugin(ScrollTrigger);

const features = [
  {
    title: "Antinuke System",
    description: "Advanced protection against server raids and unauthorized changes.",
    icon: <Shield className="w-8 h-8 text-white" />,
  },
  {
    title: "Moderation System",
    description: "Powerful tools to manage users, messages, and server safety.",
    icon: <Gavel className="w-8 h-8 text-white" />,
  },
  {
    title: "Giveaway System",
    description: "Host engaging giveaways with automated tracking and winners.",
    icon: <Gift className="w-8 h-8 text-white" />,
  },
  {
    title: "Utilities Module",
    description: "Essential tools for server management and user interaction.",
    icon: <Wrench className="w-8 h-8 text-white" />,
  },
  {
    title: "Ticket System",
    description: "Streamlined support system for your community members.",
    icon: <Ticket className="w-8 h-8 text-white" />,
  },
];

export default function Home() {
  const heroRef = useRef(null);
  const titleRef = useRef(null);
  const subtitleRef = useRef(null);
  const buttonsRef = useRef(null);
  const featuresRef = useRef(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const tl = gsap.timeline();

    tl.from(heroRef.current, { opacity: 0, duration: 1 })
      .from(titleRef.current, {
        y: 50,
        opacity: 0,
        duration: 1,
        ease: "power3.out",
      }, "-=0.5")
      .from(subtitleRef.current, {
        y: 30,
        opacity: 0,
        duration: 1,
        ease: "power3.out",
      }, "-=0.7")
      .from(buttonsRef.current, {
        y: 20,
        opacity: 0,
        duration: 0.8,
        ease: "power3.out",
      }, "-=0.5");

    // Features Animation
    gsap.fromTo(
      cardsRef.current,
      { y: 50, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        stagger: 0.1,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: featuresRef.current,
          start: "top 80%",
        },
      }
    );
  }, []);

  return (
    <div className="min-h-screen flex flex-col relative">
      {/* Hero Section */}
      <div className="min-h-screen flex flex-col items-center justify-center px-6 pt-20 relative overflow-hidden">
        <div ref={heroRef} className="text-center max-w-4xl z-10">
          {/* Logo Animation */}
          <div className="mb-8 flex justify-center">
            <img
              src={logo}
              alt="Nebula Logo"
              className="w-32 h-32 md:w-48 md:h-48 object-contain animate-pulse-slow drop-shadow-[0_0_15px_rgba(255,255,255,0.1)]"
            />
          </div>

          <h1
            ref={titleRef}
            className="text-display text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-500"
          >
            N E B U L Δ ™
          </h1>

          <p
            ref={subtitleRef}
            className="text-tech text-lg md:text-2xl text-gray-400 mb-12 tracking-widest uppercase"
          >
            A Next-Gen Multipurpose Discord Bot
          </p>

          <div
            ref={buttonsRef}
            className="flex flex-col md:flex-row gap-6 justify-center items-center"
          >
            <a
              href="https://discord.com/oauth2/authorize?client_id=1434857888081248287"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative px-8 py-4 bg-white text-black font-bold text-lg rounded-full overflow-hidden transition-all hover:scale-105 active:scale-95 w-full md:w-auto text-center min-w-[200px] border border-white"
            >
              <span className="relative z-10 flex items-center justify-center gap-2">
                Invite Bot <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </span>
              <div className="absolute inset-0 bg-gray-200 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300" />
            </a>

            <a
              href="https://dc.gg/nebula-support"
              target="_blank"
              rel="noopener noreferrer"
              className="group px-8 py-4 bg-transparent border border-white text-white font-bold text-lg rounded-full transition-all hover:scale-105 hover:bg-white/10 active:scale-95 w-full md:w-auto text-center min-w-[200px]"
            >
              Join Support
            </a>
          </div>
        </div>
        
        {/* Decorative Elements */}
        <div className="absolute bottom-10 left-0 w-full text-center opacity-30 animate-bounce">
          <span className="text-xs uppercase tracking-widest">Scroll to explore</span>
        </div>
      </div>

      {/* Features Section */}
      <div ref={featuresRef} className="py-32 px-6 container mx-auto">
        <div className="text-center mb-20">
          <h2 className="text-display text-4xl md:text-6xl font-bold mb-6">
            FEATURES
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Everything you need to build and manage a thriving community.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              ref={(el) => { cardsRef.current[index] = el; }}
              className="group glass-panel p-8 rounded-2xl hover:bg-white/5 transition-all duration-300 hover:-translate-y-2 cursor-default border border-red-500"
            >
              <div className="mb-6 p-4 bg-white/5 rounded-xl w-fit group-hover:bg-white/10 transition-colors">
                {feature.icon}
              </div>
              <h3 className="text-2xl font-bold mb-3 font-display tracking-wide">
                {feature.title}
              </h3>
              <p className="text-gray-400 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-24 px-6 container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="text-center">
            <div className="text-4xl md:text-5xl font-bold font-display mb-3">20+</div>
            <p className="text-gray-400 uppercase tracking-widest font-medium">Servers</p>
          </div>
          <div className="text-center">
            <div className="text-4xl md:text-5xl font-bold font-display mb-3">120+</div>
            <p className="text-gray-400 uppercase tracking-widest font-medium">Commands</p>
          </div>
          <div className="text-center">
            <div className="text-4xl md:text-5xl font-bold font-display mb-3">99.9%</div>
            <p className="text-gray-400 uppercase tracking-widest font-medium">Uptime</p>
          </div>
        </div>
      </div>

      {/* Premium Section */}
      <div className="py-32 px-6 container mx-auto max-w-4xl">
        <div className="glass-panel p-12 md:p-16 rounded-3xl border border-red-500 hover:border-red-400 transition-all duration-300 text-center">
          <div className="mb-8">
            <span className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 border border-white/20 rounded-full text-sm font-bold uppercase tracking-widest text-white mb-6">
              <Crown className="w-4 h-4" />
              Premium
            </span>
          </div>
          
          <h2 className="text-display text-4xl md:text-5xl font-bold mb-6">
            Unlock Premium Features
          </h2>
          
          <p className="text-gray-400 text-lg mb-10 max-w-2xl mx-auto leading-relaxed">
            Get access to exclusive features, advanced customization, priority support, and more. Elevate your community management experience with N E B U L Δ ™ Premium.
          </p>

          <div className="flex justify-center">
            <a
              href="https://dc.gg/nebula-support"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative px-10 py-5 bg-white text-black font-bold text-lg rounded-full overflow-hidden transition-all hover:scale-105 active:scale-95 min-w-[240px] border border-white"
            >
              <span className="relative z-10 flex items-center justify-center gap-2">
                Upgrade to Premium <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </span>
              <div className="absolute inset-0 bg-gray-200 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300" />
            </a>
          </div>
        </div>
      </div>

      {/* Footer Section */}
      <div className="py-20 px-6 container mx-auto max-w-4xl border-t border-white/10 mt-20">
        {/* Bot Info */}
        <div className="mb-16 pb-16 border-b border-white/10">
          <div className="flex items-center gap-4 mb-6">
            <img
              src={logo}
              alt="N E B U L Δ"
              className="w-16 h-16 object-contain"
            />
            <div>
              <h2 className="text-display text-2xl font-bold">N E B U L Δ ™</h2>
            </div>
          </div>
          <p className="text-gray-400 leading-relaxed max-w-2xl">
            A next-gen multipurpose Discord bot with advanced features including antinuke protection, moderation tools, giveaway systems, and more. Enhance your community with powerful automation and comprehensive management features.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Quick Links */}
          <div>
            <h3 className="text-display text-2xl font-bold mb-8">Quick Links</h3>
            <ul className="space-y-4">
              <li>
                <a href="/" className="text-gray-400 hover:text-white transition-colors">Home</a>
              </li>
              <li>
                <a href="/features" className="text-gray-400 hover:text-white transition-colors">Features</a>
              </li>
              <li>
                <a href="https://dc.gg/nebula-support" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">Premium</a>
              </li>
              <li>
                <a href="/support" className="text-gray-400 hover:text-white transition-colors">Support</a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-display text-2xl font-bold mb-8">Legal</h3>
            <ul className="space-y-4">
              <li>
                <a href="#privacy" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a>
              </li>
              <li>
                <a href="#terms" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a>
              </li>
              <li>
                <a href="https://dc.gg/nebula-support" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">Discord Support</a>
              </li>
            </ul>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="border-t border-white/10 mt-12 pt-8 text-center">
          <p className="text-gray-500 text-sm">© 2025 N E B U L Δ ™. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}
