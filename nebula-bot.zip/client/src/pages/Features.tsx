import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { Shield, Gavel, Gift, Wrench, Ticket } from "lucide-react";

const features = [
  {
    title: "Antinuke System",
    description: "Advanced protection against server raids and unauthorized changes.",
    icon: <Shield className="w-8 h-8 text-white" />,
  },
  {
    title: "Moderation System",
    description: "Powerful tools to manage users, messages, and server safety.",
    icon: <Gavel className="w-8 h-8 text-white" />,
  },
  {
    title: "Giveaway System",
    description: "Host engaging giveaways with automated tracking and winners.",
    icon: <Gift className="w-8 h-8 text-white" />,
  },
  {
    title: "Utilities Module",
    description: "Essential tools for server management and user interaction.",
    icon: <Wrench className="w-8 h-8 text-white" />,
  },
  {
    title: "Ticket System",
    description: "Streamlined support system for your community members.",
    icon: <Ticket className="w-8 h-8 text-white" />,
  },
];

export default function Features() {
  const containerRef = useRef(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    gsap.fromTo(
      cardsRef.current,
      { y: 50, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        stagger: 0.1,
        duration: 0.8,
        ease: "power3.out",
      }
    );
  }, []);

  return (
    <div ref={containerRef} className="min-h-screen pt-32 pb-20 px-6 container mx-auto">
      <div className="text-center mb-20">
        <h2 className="text-display text-4xl md:text-6xl font-bold mb-6">
          FEATURES
        </h2>
        <p className="text-gray-400 max-w-2xl mx-auto text-lg">
          Everything you need to build and manage a thriving community.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {features.map((feature, index) => (
          <div
            key={index}
            ref={(el) => { cardsRef.current[index] = el; }}
            className="group glass-panel p-8 rounded-2xl hover:bg-white/5 transition-all duration-300 hover:-translate-y-2 cursor-default border border-red-500"
          >
            <div className="mb-6 p-4 bg-white/5 rounded-xl w-fit group-hover:bg-white/10 transition-colors">
              {feature.icon}
            </div>
            <h3 className="text-2xl font-bold mb-3 font-display tracking-wide">
              {feature.title}
            </h3>
            <p className="text-gray-400 leading-relaxed">
              {feature.description}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
