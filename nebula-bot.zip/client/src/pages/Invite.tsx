import { useEffect } from "react";
import { gsap } from "gsap";
import { ArrowRight } from "lucide-react";

export default function Invite() {
  useEffect(() => {
    // Optional: Auto-redirect after a few seconds
    const timer = setTimeout(() => {
       window.location.href = "https://discord.com/oauth2/authorize?client_id=1434857888081248287";
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center px-6">
      <h1 className="text-display text-4xl md:text-6xl font-bold mb-8 animate-pulse-slow">
        REDIRECTING...
      </h1>
      <p className="text-gray-400 text-xl mb-12">
        You are being redirected to the Discord authorization page.
      </p>
      
      <a
        href="https://discord.com/oauth2/authorize?client_id=1434857888081248287"
        className="group relative px-8 py-4 bg-white text-black font-bold text-lg rounded-full overflow-hidden transition-all hover:scale-105 active:scale-95 inline-flex items-center gap-2"
      >
        <span className="relative z-10 flex items-center gap-2">
          Click here if not redirected <ArrowRight className="w-5 h-5" />
        </span>
        <div className="absolute inset-0 bg-gray-200 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300" />
      </a>
    </div>
  );
}
