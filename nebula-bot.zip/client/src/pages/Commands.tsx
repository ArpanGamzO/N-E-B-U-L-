import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";

const commandCategories = [
  {
    category: "Moderation",
    commands: [
      { name: "/ban", desc: "Ban a user from the server" },
      { name: "/kick", desc: "Kick a user from the server" },
      { name: "/mute", desc: "Timeout a user for a duration" },
      { name: "/purge", desc: "Bulk delete messages" },
    ],
  },
  {
    category: "Antinuke",
    commands: [
      { name: "/antinuke setup", desc: "Initialize protection system" },
      { name: "/antinuke config", desc: "View current configuration" },
      { name: "/whitelist add", desc: "Add trusted user to whitelist" },
    ],
  },
  {
    category: "Giveaways",
    commands: [
      { name: "/gstart", desc: "Start a new giveaway" },
      { name: "/gend", desc: "End an active giveaway" },
      { name: "/greroll", desc: "Reroll giveaway winner" },
    ],
  },
  {
    category: "Tickets",
    commands: [
      { name: "/ticket panel", desc: "Create a ticket creation panel" },
      { name: "/ticket close", desc: "Close the current ticket" },
      { name: "/ticket add", desc: "Add user to ticket" },
    ],
  },
  {
    category: "Utilities",
    commands: [
      { name: "/ping", desc: "Check bot latency" },
      { name: "/userinfo", desc: "Get information about a user" },
      { name: "/serverinfo", desc: "Get server statistics" },
      { name: "/avatar", desc: "View user avatar" },
    ],
  },
];

export default function Commands() {
  const containerRef = useRef(null);

  useEffect(() => {
    gsap.from(containerRef.current, {
      opacity: 0,
      y: 30,
      duration: 1,
      ease: "power3.out",
    });
  }, []);

  return (
    <div ref={containerRef} className="min-h-screen pt-32 pb-20 px-6 container mx-auto max-w-4xl">
      <div className="text-center mb-16">
        <h2 className="text-display text-4xl md:text-6xl font-bold mb-6">
          COMMANDS
        </h2>
        <p className="text-gray-400 text-lg">
          Comprehensive list of available commands.
        </p>
      </div>

      <div className="glass-panel rounded-2xl p-1 md:p-6">
        <Accordion type="single" collapsible className="w-full space-y-4">
          {commandCategories.map((cat, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="border border-white/10 rounded-xl px-4 data-[state=open]:bg-white/5 transition-colors"
            >
              <AccordionTrigger className="text-xl font-bold hover:no-underline py-6">
                {cat.category}
              </AccordionTrigger>
              <AccordionContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 pb-6">
                  {cat.commands.map((cmd, idx) => (
                    <div
                      key={idx}
                      className="flex flex-col p-3 rounded-lg bg-black/40 border border-white/5 hover:border-white/20 transition-colors"
                    >
                      <span className="font-mono text-white font-bold text-lg mb-1">
                        {cmd.name}
                      </span>
                      <span className="text-gray-400 text-sm">
                        {cmd.desc}
                      </span>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </div>
  );
}
