import { Link, useLocation } from "wouter";
import { useState, useEffect, useRef } from "react";
import { Menu, X } from "lucide-react";
import { gsap } from "gsap";
import logo from "@assets/20251117_101330_1764404311257.png";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const navRef = useRef(null);

  const links = [
    { href: "/", label: "Home" },
    { href: "/features", label: "Features" },
    { href: "/support", label: "Support" },
    { href: "https://dc.gg/nebula-support", label: "Premium", external: true, isButton: true },
  ];

  useEffect(() => {
    gsap.from(navRef.current, {
      y: -100,
      opacity: 0,
      duration: 1,
      ease: "power3.out",
    });
  }, []);

  return (
    <nav
      ref={navRef}
      className="fixed top-0 left-0 w-full z-50 border-b border-white/10 bg-black/50 backdrop-blur-md"
    >
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        {/* Logo */}
        <Link href="/">
          <a className="flex items-center gap-3 group">
            <img
              src={logo}
              alt="N E B U L Δ"
              className="w-10 h-10 object-contain transition-transform duration-300 group-hover:scale-110"
            />
            <span className="text-display font-bold text-xl tracking-wider text-white">
              N E B U L Δ ™
            </span>
          </a>
        </Link>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8">
          {links.map((link) =>
            link.external ? (
              <a
                key={link.href}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className={link.isButton ? "px-5 py-2 bg-white text-black font-bold text-sm uppercase tracking-wider rounded-full hover:bg-gray-200 transition-transform hover:scale-105 active:scale-95 border border-white" : "text-sm uppercase tracking-widest font-medium transition-all duration-300 relative py-1 text-gray-400 hover:text-white after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] after:bg-white after:transition-all after:duration-300 hover:after:w-full"}
              >
                {link.label}
              </a>
            ) : (
              <Link key={link.href} href={link.href}>
                <a
                  className={`text-sm uppercase tracking-widest font-medium transition-all duration-300 relative py-1
                  ${
                    location === link.href
                      ? "text-white"
                      : "text-gray-400 hover:text-white"
                  }
                  after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1px] after:bg-white after:transition-all after:duration-300 hover:after:w-full
                  `}
                >
                  {link.label}
                </a>
              </Link>
            )
          )}
          <a
             href="https://discord.com/oauth2/authorize?client_id=1434857888081248287"
             target="_blank"
             rel="noopener noreferrer"
             className="px-5 py-2 bg-white text-black font-bold text-sm uppercase tracking-wider rounded-full hover:bg-gray-200 transition-transform hover:scale-105 active:scale-95"
          >
            Invite
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-white"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-black border-b border-white/10 p-6 flex flex-col gap-4 shadow-2xl">
          {links.map((link) =>
            link.external ? (
              <a
                key={link.href}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsOpen(false)}
                className={link.isButton ? "block w-full text-center px-5 py-3 bg-white text-black font-bold uppercase tracking-wider rounded-full border border-white" : "text-lg font-medium block text-gray-400 hover:text-white"}
              >
                {link.label}
              </a>
            ) : (
              <Link key={link.href} href={link.href}>
                <a
                  onClick={() => setIsOpen(false)}
                  className={`text-lg font-medium block ${
                    location === link.href ? "text-white" : "text-gray-400"
                  }`}
                >
                  {link.label}
                </a>
              </Link>
            )
          )}
          <a
             href="https://discord.com/oauth2/authorize?client_id=1434857888081248287"
             target="_blank"
             rel="noopener noreferrer"
             className="block w-full text-center px-5 py-3 bg-white text-black font-bold uppercase tracking-wider rounded-full"
          >
            Invite Bot
          </a>
        </div>
      )}
    </nav>
  );
}
