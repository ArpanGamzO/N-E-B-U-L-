import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

export default function StarBackground() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const starCount = 100;
    const container = containerRef.current;

    // Clear existing stars to prevent duplication on re-renders if not handled carefully
    container.innerHTML = '';

    for (let i = 0; i < starCount; i++) {
      const star = document.createElement('div');
      star.classList.add('star');
      
      // Random positioning
      const x = Math.random() * 100;
      const y = Math.random() * 100;
      const size = Math.random() * 2 + 1; // 1px to 3px
      const duration = Math.random() * 10 + 10; // 10s to 20s
      const delay = Math.random() * 10;
      const opacity = Math.random() * 0.7 + 0.3;

      star.style.left = `${x}%`;
      star.style.top = `${y}%`;
      star.style.width = `${size}px`;
      star.style.height = `${size}px`;
      star.style.setProperty('--opacity', `${opacity}`);
      star.style.animationDuration = `${duration}s`;
      star.style.animationDelay = `-${delay}s`; // Negative delay to start immediately

      container.appendChild(star);
    }
  }, []);

  return <div ref={containerRef} className="stars-container" />;
}
