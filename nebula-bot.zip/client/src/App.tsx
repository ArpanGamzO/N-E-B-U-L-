import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Navbar from "@/components/layout/Navbar";
import StarBackground from "@/components/layout/StarBackground";
import Home from "@/pages/Home";
import Features from "@/pages/Features";
import Commands from "@/pages/Commands";
import Support from "@/pages/Support";
import Invite from "@/pages/Invite";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/features" component={Features} />
      <Route path="/commands" component={Commands} />
      <Route path="/support" component={Support} />
      <Route path="/invite" component={Invite} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <StarBackground />
      <Navbar />
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
